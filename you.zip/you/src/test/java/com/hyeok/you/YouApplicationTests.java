package com.hyeok.you;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YouApplicationTests {

	@Test
	void contextLoads() {
	}

}
