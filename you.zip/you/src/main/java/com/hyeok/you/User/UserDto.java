package com.hyeok.you.User;

import lombok.*;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class UserDto {
    private Long id;

    @NotBlank(message = "이메일은 필수 입력 값입니다.")
    @Email(message = "이메일 형식에 맞지 않습니다.")
    private String email; //email 양식이어야함

    @NotBlank(message = "닉네임은 필수 입력 값입니다.") //null을 허용하지 않음, 적어도 white-space가 아닌 문자가 한개 이상 포함되어야 함
    private String nickname;

    @NotBlank(message = "비밀번호는 필수 입력 값입니다.")
    @Pattern(regexp = "(?=.*[0-9])(?=.*[a-zA-Z])(?=.*\\W)(?=\\S+$).{8,20}",
            message = "비밀번호는 영문 대,소문자와 숫자, 특수기호가 적어도 1개 이상씩 포함된 8자 ~ 20자의 비밀번호여야 합니다.")
    //(?=.*[0-9]) 숫자 적어도 하나
    //(?=.*[a-zA-Z]) 영문 대,소문자중 적어도 하나
    //(?=.*\W) 특수문자 적어도 하나
    //(?=.*\S+$) 공백제거
    //{8, 20} 글자수 8 ~ 20자 이내
    private String password;

    @Builder
    public UserDto(Long id, String nickname, String email, String password) {
        this.id = id;
        this.nickname = nickname;
        this.email = email;
        this.password = password;
    }
}
/*
dto는 데이터 전달 객체로서, 다음과 같은 목적으로 활용됩니다.

1. 클라이언트의 요청 데이터가 dto 클래스로 캡슐화되어 서버로 전달
2. Controller <---> Service 계층 간 데이터 전달

따라서 유효성 검사는 1번의 케이스로 dto를 활용을 할 수 있습니다.
이렇게 dto 클래스의 필드에 각종 어노테이션을 추가해주면 유효성 체크를 할 수 있고, 조건을 만족 못할 경우 에러 메시지를 반환.

@NotEmpty
null과 공백 문자열("")을 허용하지 않음

@NotBlack
null과 빈 공백 문자열(" ")을 허용하지 않음
 */