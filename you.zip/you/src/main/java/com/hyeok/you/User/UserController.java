package com.hyeok.you.User;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;
import java.util.Map;

@Controller
@AllArgsConstructor
public class UserController {
    private UserService userService;

    @GetMapping("/user/signup")
    public String dispSignup(UserDto userDto) {
        return "/signup";
    }

    @PostMapping("/user/signup")
    public String execSignup(@Valid UserDto userDto, Errors errors, Model model) {
        if (errors.hasErrors()) {
            // 회원가입 실패시, 입력 데이터를 유지
            model.addAttribute("userDto", userDto);

            // 유효성 통과 못한 필드와 메시지를 핸들링
            Map<String, String> validatorResult = userService.validateHandling(errors);
            for (String key : validatorResult.keySet()) {
                model.addAttribute(key, validatorResult.get(key));
            }
            return "/signup";
        }
        userService.signUp(userDto);
        return "redirect:/user/login";
    }

    //로그인 페이지
    //UserDto 받는 이유 - 회원가입 실패시, 회원가입 페이지에서 입력했던 정보들을 그대로 유지하기 위해 입력받았던 데이터를 그대로 할당.
    @GetMapping("/user/login")
    public String displogin() {
        return "/login";
    }
}
/*
@Valid
클라이언트의 입력 데이터가 dto 클래스로 캡슐화되어 넘어올때, 유효성을 체크하라는 어노테이션입니다.
앞에서 dto 클래스에 작성한 어노테이션을 기준으로 유효성을 체크합니다.

Errors 객체
dto에 binding된 필드의 유효성 검사 오류에 대한 정보를 저장하고 노출합니다.
errors.hasErrors()는 유효성 검사에 실패한 필드가 있는지 확인
model.addAttribute("userDto", userDto);
회원가입 실패 시, 회원가입 페이지에서 입력했던 정보들을 그대로 유지하기 위해 입력받았던 데이터를 그대로 할당합니다.
  dispSignup(USerDto userDto)함수에 파라미터를 정의해준 이유
  Validation 관점에서는 필요업는 부분이지만, UX측면에서 구현해주는 것이 좋아보입니다.
  물론, thymeleaf에서도 코드가 들어가야 합니다.
 */
