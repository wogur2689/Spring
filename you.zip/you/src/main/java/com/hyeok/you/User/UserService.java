package com.hyeok.you.User;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import java.util.HashMap;
import java.util.Map;

@Service
@AllArgsConstructor
public class UserService {
    //회원가입 시, 유효성 체크
    public Map<String, String> validateHandling(Errors errors) {
        Map<String, String> validatorResult = new HashMap<>();

        for (FieldError error : errors.getFieldErrors()) {
            String validKeyName = String.format("valid_%s", error.getField());
            validatorResult.put(validKeyName, error.getDefaultMessage());
        }

        return validatorResult;
    }

    // 회원가입
    public void signUp(UserDto userDto) {
        // 회원 가입 비즈니스 로직 구현
    }
}

/*
유효성 검사에 실패한 필드들은 Map 자료구조를 이용하여 키값과 에러 메시지를 응답합니다.
  - 키 : valid_{dto 필드명}
  - 메시지 : dto에서 작성한 message 값
  - errors.getFieldErrors() : 유효성 검사에 실패한 필드 목록을 가져옵니다.
  - errors.getField() : 유효성 검사에 실패한 필드명을 가져옵니다.
  - errors.getDefaultMessage() : 유효성 검사에 실패한 필드에 정의된 메시지를 가져옵니다.
 */