package com.hyeok.board.domain.repository;

import com.hyeok.board.domain.entity.BoardEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoardRepository extends JpaRepository<BoardEntity, Long> {

}

/*
레포지토리는 인터페이스로 정의, JpaRepository 인터페이스를 상속
JpaRepository
- 제네릭 타입에는 Entity 클래스와 PK의 타입을 명시
- 일반적으로 많이 사용하는 데이터 조작을 다루는 함수가 정의 -> CRUD작업이 편함.
 */
