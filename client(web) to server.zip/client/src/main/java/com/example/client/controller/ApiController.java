package com.example.client.controller;

import com.example.client.dto.Test;
import com.example.client.service.TestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
@RequiredArgsConstructor
public class ApiController {

    private final TestService testService;
    private static Test test = new Test();

    @GetMapping("/")
    public String input() {
        return "input";
    }

    @RequestMapping(value = "/result", method = {RequestMethod.GET, RequestMethod.POST})
    public String Test(HttpServletRequest request, Model model) throws IOException {
        test.setNum1(Integer.parseInt(request.getParameter("num1")));
        test.setNum2(Integer.parseInt(request.getParameter("num2")));
        test.setMark(request.getParameter("mark"));

        testService.postForEntity(test);
        model.addAttribute("res", test.getRes());

        return "/result";
    }

    //POST로 바꾸기 OK, OkHttp 사용하기 OK, 두 값의 합계 구하기
}
