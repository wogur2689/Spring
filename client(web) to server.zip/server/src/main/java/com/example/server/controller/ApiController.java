package com.example.server.controller;

import com.example.server.dto.Test;
import com.example.server.service.TestService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/result")
public class ApiController {

    private static TestService testService = new TestService();

    @PostMapping("")
    public Test post(@RequestBody Test test){
        int num1 = test.getNum1();
        int num2 = test.getNum2();
        String mark = test.getMark();
        int res = test.getRes();

        res = testService.result(num1, num2, mark, res);

        test.setRes(res);
        return test;
    }

    /*@GetMapping("")
    public Test get(@RequestParam int num1, @RequestParam int num2, @RequestParam String mark, @RequestParam int res) {
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(mark);
        System.out.println(res);

        Test test = new Test();
        test.setNum1(num1);
        test.setNum2(num2);
        test.setMark(mark);
        test.setRes(res);
        //int as = result();
        //System.out.println(as);

        return test;
    }*/

     /* public int result() {
        Test test = new Test();
        int num1 = test.getNum1();
        int num2 = test.getNum2();
        String mark = test.getMark();
        int res = 20;

        if(mark.equals("+"))
            res = num1 + num2;
        else if(mark.equals("-"))
            res = num1 - num2;
        else if(mark.equals("*"))
            res = num1 * num2;
        else if(mark.equals("/"))
            res = num1 / num2;
        else res = 0;

        return res;
     }*/


}
