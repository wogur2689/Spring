package com.example.server.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Test {
    private int num1; //첫번째 수
    private int num2; //두번째 수
    private String mark; //세번째 수
    private int res;  //결과
}
