create table study (
	id int NOT null,
	name varchar(50) null,
	address varchar(200) null,
	PRIMARY KEY (id)
);

insert into study(id, name, address) 
values ('1', '철수', '서울');
insert into study(id, name, address) 
values ('2', '영희', '대전');
insert into study(id, name, address) 
values ('3', '둘리', '천안');
insert into study(id, name, address) 
values ('4', '바다', '인천');

select *
from study;
