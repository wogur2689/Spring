package com.example.objectmapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObjectMapperApplicationTests {

    @Test
    void contextLoads() throws JsonProcessingException {
        System.out.println("-----");

        //Text JSON -> Object
        //Object -> Text JSON

        // controller req json(text) -> object
        // response object -> json(text)
        //지금까지 자동적으로 바꾸고 있었음.

        var objectMapper = new ObjectMapper();

        // object -> Text
        // objcetMapper는 get메소드를 활용함.
        var user = new User("콜라짱", 20, "010-1111-2222");
        var text = objectMapper.writeValueAsString(user);
        System.out.println(text);

        // Text -> object
        // objcetMapper는 default 생성자가 필요함.
        var objectUser = objectMapper.readValue(text, User.class);
        System.out.println(objectUser);
    }

}
