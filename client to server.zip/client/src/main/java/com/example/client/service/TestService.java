package com.example.client.service;

import com.example.client.dto.Test;
import okhttp3.*;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;

@Service
public class TestService {

    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    OkHttpClient client = new OkHttpClient();

    public void postForEntity() throws IOException {
        URI uri = UriComponentsBuilder
                .fromUriString("http://localhost:2222")
                .path("/api/{path}")
                .encode()
                .build()
                .expand("test")
                .toUri();

        Test test = new Test();
        test.setNum1(30);
        test.setNum2(30);
        test.setMark("+");
        test.setRes(0);

        System.out.println(post(uri.toString(), test.toString()));

        // Json문자열 값만 출력하는 코드
        String str = post(uri.toString(), test.toString());
        str = str.substring(str.indexOf("{")+1, str.lastIndexOf("}"));
        String data[] = str.split(",");

        for(int i = 0; i < data.length; i++) {
            data[i] = data[i].substring(data[i].indexOf(":")+1);
            System.out.println(data[i]);
        }
        test.setNum1(Integer.parseInt(data[0])); //서버에서 받아온 값을 setter를 이용해 저장
        test.setNum2(Integer.parseInt(data[1])); //서버에서 받아온 값을 setter를 이용해 저장
        test.setMark(data[2]);                   //String이라 형변환 필요없음.
        test.setRes(Integer.parseInt(data[3]));  //서버에서 받아온 값을 setter을 이용해 저장
    }

    String post(String url, String json) throws IOException {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            return response.body().string();
        }
    }

}
