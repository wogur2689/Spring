package com.example.client.controller;

import com.example.client.service.TestService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequestMapping("/api/test")
@RequiredArgsConstructor
public class ApiController {

    private final TestService testService;

    /*@GetMapping("")
    public void get() {
        testService.getForEntity();
    }*/

    @PostMapping("")
    public void post() throws IOException {
        testService.postForEntity();
    }

    //POST로 바꾸기 OK, OkHttp 사용하기 OK, 두 값의 합계 구하기
}
