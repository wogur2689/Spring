package com.example.server.service;

import com.example.server.dto.Test;
import org.springframework.stereotype.Service;

@Service
public class TestService {

    private static Test test = new Test();

    public int result(int num1, int num2, String mark, int res) {
        if(mark.equals("+"))
            res = num1 + num2;
        else if(mark.equals("-"))
            res = num1 - num2;
        else if(mark.equals("*"))
            res = num1 * num2;
        else if(mark.equals("/"))
            res = num1 / num2;
        else res = 0;

        return res;
    }

}
