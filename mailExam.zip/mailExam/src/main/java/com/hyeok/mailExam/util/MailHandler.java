package com.hyeok.mailExam.util;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.IOException;

public class MailHandler {
    private JavaMailSender sender;
    private MimeMessage message;
    private MimeMessageHelper messageHelper;

    //생성자
    public MailHandler(JavaMailSender jSender) throws MessagingException {
        this.sender = jSender;
        message = jSender.createMimeMessage();
        messageHelper = new MimeMessageHelper(message, true, "UTF-8");
    }

    //보내는 사람 이메일
    public void setFrom(String fromAddress) throws MessagingException {
        messageHelper.setFrom(fromAddress);
    }

    //받는 사람 이메일
    public void setTo(String email) throws MessagingException {
        messageHelper.setTo(email);
    }

    //제목
    public void setSubject(String subject) throws MessagingException {
        messageHelper.setSubject(subject);
    }

    //메일 내용
    public void setText(String text, boolean useHtml) throws MessagingException {
        messageHelper.setText(text, useHtml);
    }

    //첨부 파일
    public void setAttach(String displayFileName, String pathToAttachment) throws MessagingException, IOException {
        File file = new ClassPathResource(pathToAttachment).getFile();
        FileSystemResource fsr = new FileSystemResource(file);

        messageHelper.addAttachment(displayFileName, fsr);
    }

    //이미지 삽입
    public void setInline(String contentId, String pathToInline) throws MessagingException, IOException {
        File file = new ClassPathResource(pathToInline).getFile();
        FileSystemResource fsr = new FileSystemResource(file);

        messageHelper.addInline(contentId, fsr);
    }

    //발송
    public void send() {
        try {
            sender.send(message);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
/*
MineMessageHelper
- 스프링에서 제공하는 헬퍼 객체이며, HTML 레이아웃, 이미지 삽입, 첨부파일 등 MIME 메시지를 생성할 수 있습니다.
- 생성자
  - MimeMessageHelper(MimeMessage mimeMessage, boolean multipart, @Nullable String encoding)
- 또한 앞서 살펴본 SimpleMailMEssage의 메서드를 모두 지원하고 있으며, 추가된 메서드는 다음과 같습니다.
  - messageHelper.setText - 메일 내용
    - 두 번째 파라미터에 HTML 사용여부를 전달합니다.
  - messageHelper.addAttachment - 첨부 파일
    - 첫 번째 파라미터에 메일에 노출된 파일 이름을 작성합니다.
    - 두 번째 파라미터에 파일의 경로를 작성합니다.
  - messageHelper.addInline(contentId, fsr) - 이미지 삽입
    - 첫 번째 파라미터에 삽입될 이미지의 id 애트리뷰트명을 작성합니다.
    - 두 번째 파라미터에 파일의 경로를 작성합니다.
 */