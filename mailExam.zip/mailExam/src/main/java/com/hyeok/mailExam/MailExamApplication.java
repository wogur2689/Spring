package com.hyeok.mailExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailExamApplication.class, args);
	}

}
