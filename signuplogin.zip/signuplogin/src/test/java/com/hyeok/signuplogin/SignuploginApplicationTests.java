package com.hyeok.signuplogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignuploginApplicationTests {

	@Test
	void contextLoads() {
	}

}
