package com.example.put;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PutApplication {

    public static void main(String[] args) {
        SpringApplication.run(PutApplication.class, args);
    }

}
