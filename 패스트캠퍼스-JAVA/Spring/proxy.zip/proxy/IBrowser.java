package com.example.bread.proxy;

public interface IBrowser {
    Html show();
}
