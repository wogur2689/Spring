package com.example.bread.proxy;

public class Html {
    private String url;

    public Html(String url) {
        this.url = url;
    }
}
