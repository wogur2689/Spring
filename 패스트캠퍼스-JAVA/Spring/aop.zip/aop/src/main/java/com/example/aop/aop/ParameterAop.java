package com.example.aop.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Aspect //aop동작
@Component //spring에서 관리하기 위해 been으로 등록
public class ParameterAop {

    //컨트롤러 패키지에 있는 모든 클래스에 적용
    @Pointcut("execution(* com.example.aop.controller..*.*(..))") //어느부분에 이것을 적용할 것인지.
    private void cut() {

    }

    @Before("cut()") //언제 실행을 시킬 것인지(위에 cut가 실행되면 실행)
    public void before(JoinPoint joinPoint) {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        System.out.println(method.getName());
        Object[] args = joinPoint.getArgs();
        for(Object obj : args) {
            System.out.println("type : " + obj.getClass().getSimpleName());
            System.out.println("value : " + obj);
        }
    }

    @AfterReturning(value = "cut()", returning = "returnObj") //실행후 returning를 통해 볼수있음.
    public void afterReturn(JoinPoint joinPoint, Object returnObj) {
        System.out.println("returnObj : " + returnObj);
    }

}
