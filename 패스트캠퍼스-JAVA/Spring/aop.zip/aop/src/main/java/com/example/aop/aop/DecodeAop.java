package com.example.aop.aop;

import com.example.aop.dto.User;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

@Aspect
@Component
public class DecodeAop {
    //컨트롤러 패키지에 있는 모든 클래스에 적용
    @Pointcut("execution(* com.example.aop.controller..*.*(..))") //어느부분에 이것을 적용할 것인지.
    private void cut() {

    }

    @Pointcut("@annotation(com.example.aop.annotation.Decode)")
    private void enableDecode() {

    }

    @Before("cut() && enableDecode()")
    public void before(JoinPoint joinPoint) throws UnsupportedEncodingException {
        Object[] args = joinPoint.getArgs();

        for(Object arg : args) {
            if(arg instanceof User) { //user란 클래스가 매칭이 되면 형변환
                User user = User.class.cast(arg);
                String base64Email = user.getEmail(); //이메일 꺼내서 인코딩
                String email = new String(Base64.getDecoder().decode(base64Email.getBytes()), "UTF-8"); //디코딩
                user.setEmail(email); //이메일 vo에 저장
            }
        }

    }

    @AfterReturning(value = "cut() && enableDecode()", returning = "returnObj")
    public void afterReturn(JoinPoint joinPoint, Object returnObj) {
        if(returnObj instanceof User) {
            User user = User.class.cast(returnObj);
            String email = user.getEmail(); //이메일 꺼내기
            String base64Email = Base64.getEncoder().encodeToString(email.getBytes()); //이메일 인코딩
            user.setEmail(base64Email); //이메일 vo에 저장
        }
    }

}
