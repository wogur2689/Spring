package com.example.aop.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect
@Component
public class TimerAop {

    //컨트롤러 패키지에 있는 모든 클래스에 적용
    @Pointcut("execution(* com.example.aop.controller..*.*(..))") //어느부분에 이것을 적용할 것인지.
    private void cut() {

    }

    @Pointcut("@annotation(com.example.aop.annotation.Timer)")
    private void enableTimer() {

    }

    @Around("cut() && enableTimer()")
    public void around(ProceedingJoinPoint joinPoint) throws Throwable {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start(); //타이머 시작

        Object result = joinPoint.proceed(); //메소드 실행되는 곳

        stopWatch.stop(); //타이머 종료

        System.out.println("total time : " + stopWatch.getTotalTimeSeconds());
    }

}
