package com.example.study.component;

import org.springframework.stereotype.Component;

@Component
public class MarketApi {
    public int connect() {
        return 1100;
    }
}
