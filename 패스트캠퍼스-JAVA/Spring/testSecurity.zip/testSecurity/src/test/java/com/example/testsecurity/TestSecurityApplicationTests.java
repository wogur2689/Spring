package com.example.testsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
