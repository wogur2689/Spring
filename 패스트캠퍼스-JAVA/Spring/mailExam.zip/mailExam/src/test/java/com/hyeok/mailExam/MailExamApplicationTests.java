package com.hyeok.mailExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
