package com.hyeok.mailExam.service;

import com.hyeok.mailExam.dto.MailDto;
import com.hyeok.mailExam.util.MailHandler;
import lombok.AllArgsConstructor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;


@Service
@AllArgsConstructor
public class MailService {
    private JavaMailSender mailSender;
    private static final String FROM_ADDRESS = "이메일주소";

    public void mailSend(MailDto mailDto) {
        try {
            MailHandler mailHandler = new MailHandler(mailSender);

            //받는 사람
            mailHandler.setTo(mailDto.getAddress());
            //보내는 사람
            mailHandler.setFrom(MailService.FROM_ADDRESS);
            //제목
            mailHandler.setSubject(mailDto.getTitle());
            //HTML Layout
            String htmlContent = "<p>" + mailDto.getMessage() + "<p> <img src='cid:simple-img'>";
            mailHandler.setText(htmlContent, true);
            //첨부 파일
            mailHandler.setAttach("newTest.txt", "static/originTest.txt");
            //이미지 삽입
            mailHandler.setInline("sample-img", "static/sample1.jpg");

            mailHandler.send();

        } catch (Exception e) {
            e.printStackTrace();
        }
        /*
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(mailDto.getAddress());
        message.setFrom(MailService.FROM_ADDRESS);
        message.setSubject(mailDto.getTitle());
        message.setText(mailDto.getMessage());

        mailSender.send(message);
         */
    }
}
/*
JavaMailSender
 - MailSender 인터페이스를 상속받았으며, MIME를 지원합니다.(여기서는 단순 텍스트를 발송하지만요.)
 - JavaMailSenderImpl Bean이 DI되는데, JavaMailSenderImpl은 JavaMailSender의 구현체

 FROM_ADDRESS
 - 보내는 사람의 이메일 주소를 상수로 정의
 - 해당 값은 application에서 @Value로 가져와도 되고, 비즈니스에 따라 값을 유동적으로 바꿔도 됩니다.

 SimpleMailMessage
 - 이메일 메시지 정보를 작성합니다.
   - setTo : 받는 사람 주소
   - setFrom : 보는 사람 주소 / 미호출시 application에 작성한 username으로 셋팅.
   - setSubject() : 제목
   - setText() 메시지 내용

 mailSender.send
   - 실제 메일 발송 부분
 */