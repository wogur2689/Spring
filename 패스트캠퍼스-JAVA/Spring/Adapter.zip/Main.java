package com.example.bread.adapter;

public class Main {
    public static void main(String[] args) {
        HairDryer hairDryer = new HairDryer();
        connect(hairDryer);

        Cleaner cleaner = new Cleaner();
        //connect(cleaner); //청소기는 220V를 사용하기 때문에 콘센트와는 맞지 않음.

        Electronic110v adapter = new SocketAdapter(cleaner);
        connect(adapter);

        AirConditioner airConditioner = new AirConditioner();
        //connect(airConditioner); //에어컨은 220V를 사용하기 때문에 콘센트와는 맞지 않음.
        Electronic110v airAdapter = new SocketAdapter(airConditioner);
        connect(airAdapter);
    }

    //콘센트
    public static void connect(Electronic110v electronic110v) {
        electronic110v.powerOn();
    }
}
