package com.example.bread.adapter;

public interface Electronic110v {
    void powerOn();
}
