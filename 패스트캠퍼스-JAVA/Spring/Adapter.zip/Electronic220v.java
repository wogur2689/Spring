package com.example.bread.adapter;

public interface Electronic220v {
    void connect();
}
