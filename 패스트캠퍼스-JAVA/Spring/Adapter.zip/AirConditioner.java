package com.example.bread.adapter;

public class AirConditioner implements Electronic220v{

    @Override
    public void connect() {
        System.out.println("에어컨 200V on");
    }
}
