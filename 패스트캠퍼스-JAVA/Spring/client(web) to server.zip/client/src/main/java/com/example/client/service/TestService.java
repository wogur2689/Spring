package com.example.client.service;

import com.example.client.dto.Test;
import okhttp3.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;

@Service
public class TestService {

    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    //MediaType : 인터넷에 전달되는 파일 포맷과 포맷 콘텐츠를 위한 식별자고, HTTP와 HTML 문서 파일 포맷에 사용
    /*
       request와 response에 MediaType을 지정해서 요청받을 때
       사용하는 MediaType과 응답할 때 보내주는 MediaType을 지정, 사전에 필요한 타입만 거를 수 있다.
       json으로 명시해 두었기 때문에 json으로 받음.
     */
    //문자셋은 UTF-8로 설정.

    OkHttpClient client = new OkHttpClient();

    public void postForEntity(Test test) throws IOException, ParseException {
        //서버 uri지정
        URI uri = UriComponentsBuilder
                .fromUriString("http://localhost:2222")
                .path("/result")
                .encode()
                .build()
                .expand()
                .toUri();

        // Json문자열 값만 출력하는 코드
        String str = post(uri.toString(), test.toString());
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonObject = (JSONObject)jsonParser.parse(str);
        test.setRes(Integer.parseInt(String.valueOf(jsonObject.get("res"))));
    }

    String post(String url, String json) throws IOException {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            return response.body().string();
        }
    }

}
