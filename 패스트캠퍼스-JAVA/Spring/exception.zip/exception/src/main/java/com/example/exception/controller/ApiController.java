package com.example.exception.controller;

import com.example.exception.dto.User;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Validated
@RestController
@RequestMapping("/api/user")
public class ApiController {

    /**
     * required = false 속성은 이 파라미터가 없어도 동작하게함.
     * @param name
     * @param age
     * @return
     */
    @GetMapping("")
    public User get(@Size(min = 2) @RequestParam String name, @NotNull @Min(1) @RequestParam Integer age) {
        User user = new User();
        user.setName(name);
        user.setAge(age);

        int a = 10 + age;

        return user;
    }

    @PostMapping("")
    public User post(@RequestBody User user) {
        System.out.println(user);
        return user;
    }
}
