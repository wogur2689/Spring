package com.example.demo.controller;

import com.example.demo.dto.PostRequestDto;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController //REST API를 처리하는 컨트롤러
@RequestMapping("/api") //RequestMapping URI를 지정해주는 어노테이션
public class ApiController {

    @PostMapping("/post")
    public void post(@RequestBody PostRequestDto requestData) {
        System.out.println(requestData);
    }
    //RequestBody라는 어노테이션을 통해 Json을 파싱.
}
