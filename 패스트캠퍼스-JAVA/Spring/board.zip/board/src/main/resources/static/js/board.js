console.log(boardDto);
//컨트롤러에서 넘겨준 Java변수를 js에서 어떻게 사용할 수 있는지 알아보기 위한 예제.