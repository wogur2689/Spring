package com.example.demo.controller;

import com.example.demo.dto.UserRequest;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController //REST API를 처리하는 컨트롤러
@RequestMapping("/api") //RequestMapping URI를 지정해주는 어노테이션
public class ApiController {

    @GetMapping(path = "/hello") //http://localhost:8080/api/hello
    public String hello() {
        return "get hello";
    }

    @RequestMapping(path = "/hi", method = RequestMethod.GET) // get http://localhost:8080/api/get/hi
    public String h1() {
        return "h1";
    }

    //http://localhost:8080/api/get/path-variable
    @GetMapping("/path-variable/{id}")
    public String pathVariable(@PathVariable(name = "id") String pathName) {
        System.out.println("PathVariable" + pathName);
        return pathName;
    }

    //http://localhost:8080/api/get/query-param?user=steve&email=steve@gamil.com&age=30
    @GetMapping(path = "query-param")
    public String queryParam(@RequestParam Map<String, String> queryParam) {
        StringBuffer sb = new StringBuffer();

        queryParam.entrySet().forEach( entry -> {
            System.out.println(entry.getKey());
            System.out.println(entry.getValue());
            System.out.println("\n");

            sb.append(entry.getKey() + " = " + entry.getValue() + "\n");
        });

        return sb.toString();
    }

    @GetMapping("query-param02")
    public String queryParam02(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam int age
    ){
        System.out.println(name);
        System.out.println(email);
        System.out.println(age);

        return name+" "+email+" "+age;
    }

    @GetMapping("query-param03")
    public String queryParam03(UserRequest userRequest){
        System.out.println(userRequest.getName());
        System.out.println(userRequest.getEmail());
        System.out.println(userRequest.getAge());

        return userRequest.toString();
    }

}
