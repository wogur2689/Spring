package com.example.client.controller;

import com.example.client.dto.Test;
import com.example.client.service.TestService;
import lombok.RequiredArgsConstructor;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
@RequiredArgsConstructor
public class ApiController {

    private final TestService testService; //서비스 사용 선언
    private static Test test = new Test(); //dto 객체 생성

    @GetMapping("/")
    public String input() {
        return "input";
    }

    @RequestMapping(value = "/result", method = RequestMethod.POST)
    public String Test(HttpServletRequest request, Model model) throws IOException, JSONException, ParseException {
        test.setNum1(Integer.parseInt(request.getParameter("num1"))); //request로 받아온 파라메터를 int형으로 전환해서 setter로 저장.
        test.setNum2(Integer.parseInt(request.getParameter("num2")));
        test.setMark(request.getParameter("mark")); //string이라 형변환이 필요없음.

        //서비스에서 서버전송 진행
        testService.postForEntity(test);

        //모델에 test에 저장된 값을 얻어와서 추가.
        model.addAttribute("res", test.getRes());

        //결과 페이지로 반환.
        return "/result";
    }
}
