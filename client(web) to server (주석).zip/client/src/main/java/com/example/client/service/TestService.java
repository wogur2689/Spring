package com.example.client.service;

import com.example.client.dto.Test;
import okhttp3.*;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;

@Service
public class TestService {

    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    //MediaType : 인터넷에 전달되는 파일 포맷과 포맷 콘텐츠를 위한 식별자고, HTTP와 HTML 문서 파일 포맷에 사용
    /*
       request와 response에 MediaType을 지정해서 요청받을 때
       사용하는 MediaType과 응답할 때 보내주는 MediaType을 지정, 사전에 필요한 타입만 거를 수 있다.
       json으로 명시해 두었기 때문에 json으로 받음.
     */
    //문자셋은 UTF-8로 설정.

    OkHttpClient client = new OkHttpClient();
    //OkHttp클라이언트 생성

    public void postForEntity(Test test) throws IOException, JSONException, ParseException {
        URI uri = UriComponentsBuilder
                .fromUriString("http://localhost:2222")
                .path("/result")
                .encode()
                .build()
                .expand()
                .toUri();
            //서버 uri지정
            String str = post(uri.toString(), test.toString());
            //콜백이 되면 response에 저장하여 리턴
            //리턴할때 json으로 변환후 다시 string으로 반환.

            //JSONParser객체 생성
            JSONParser jsonParser = new JSONParser();

            //JSONObject객체에 반환된 값을 jsonObject로 바꿔서 넣음
            JSONObject jsonObject = (JSONObject)jsonParser.parse(str);
            //jsonObject에서 res값을 얻어와 string으로 변환 후 Int값으로 변환해서 저장
            int s = Integer.parseInt(String.valueOf(jsonObject.get("res")));
            //setter를 이용해 저장
            test.setRes(s);

            //Post 클래스를 통해 서버로 전송되고 반환된 값을 받아서 String 객체에 저장
    }

    //default post 클래스
    String post(String url, String json) throws IOException {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        //받아온 데이터를 json으로 request변수에 저장.
        try (Response response = client.newCall(request).execute()) {
            //콜백이 되면 response에 저장하여 리턴
            //리턴할때 json으로 변환후 다시 string으로 반환.
            return response.body().string();
        }
    }

}
