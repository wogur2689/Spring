package com.example.client.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data //setter getter
@NoArgsConstructor
@AllArgsConstructor
public class Test {
    private int num1; //첫번째 수
    private int num2; //두번째 수
    private String mark; //연산자
    private int res;  //연산결과

    //toString하면 json의 형태 변환.
    @Override
    public String toString() {
        return "{" +
                " \"num1\" : " + num1 +
                ",\"num2\" : " + num2 +
                ",\"mark\" : \"" + mark + '\"' +
                ",\"res\" : " + res +
                "}";
    }
}
