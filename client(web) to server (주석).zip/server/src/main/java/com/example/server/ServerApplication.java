package com.example.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.Scheduled;

import java.text.SimpleDateFormat;
import java.util.Date;

@SpringBootApplication
public class ServerApplication {

	@Scheduled(cron = "5 * * * * *", zone = "Asia/Seoul")
	public static void run() {
		System.out.println("A회사");
		Date today = new Date();
		SimpleDateFormat time = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss a");
		System.out.println("Time: " + time.format(today));
	}

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}
