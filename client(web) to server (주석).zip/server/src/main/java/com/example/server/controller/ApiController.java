package com.example.server.controller;

import com.example.server.dto.Test;
import com.example.server.service.TestService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/result")
public class ApiController {

    //서비스 생성
    private static TestService testService = new TestService();

    @PostMapping("")
    public Test post(@RequestBody Test test){
        //서비스에서 사칙연산 수행.
        int res = testService.result(test);
        // 사칙연산 수행 결과를 setter을 이용해 저장 후 반환.
        test.setRes(res);
        return test;
    }
}