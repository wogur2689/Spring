package com.example.server.service;

import com.example.server.dto.Test;
import org.springframework.stereotype.Service;

@Service //service
public class TestService {

    //사칙연산
    public int result(Test test) {
        int num1 = test.getNum1();
        int num2 = test.getNum2();
        String mark = test.getMark();
        int res;
        //mark에 따라 나온 결과를 반환.
        if(mark.equals("+")) res = num1 + num2;
        else if(mark.equals("-")) res = num1 - num2;
        else if(mark.equals("*")) res = num1 * num2;
        else if(mark.equals("/")) res = num1 / num2;
        else res = 0;

        return res;
    }

}